-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 13/09/2026 às 17:50
-- Versão do servidor: 10.4.32-MariaDB
-- Versão do PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `nutriscan`
--
CREATE DATABASE IF NOT EXISTS `nutriscan` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `nutriscan`;

-- --------------------------------------------------------

--
-- Estrutura para tabela `alimentos`
--

CREATE TABLE `alimentos` (
  `id` int(10) UNSIGNED NOT NULL,
  `nome` varchar(500) NOT NULL,
  `codigo_barras` varchar(50) NOT NULL DEFAULT '',
  `categoria` varchar(255) DEFAULT NULL,
  `calorias` decimal(8,2) DEFAULT NULL,
  `carboidratos` decimal(8,2) DEFAULT NULL,
  `proteinas` decimal(8,2) DEFAULT NULL,
  `gorduras` decimal(8,2) DEFAULT NULL,
  `sodio` decimal(8,2) DEFAULT NULL,
  `acucares` decimal(8,2) DEFAULT NULL,
  `fibras` decimal(8,2) DEFAULT NULL,
  `preco` decimal(8,2) DEFAULT NULL,
  `criado_em` datetime NOT NULL DEFAULT current_timestamp(),
  `atualizado_em` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ;

--
-- Despejando dados para a tabela `alimentos`
--

INSERT INTO `alimentos` (`id`, `nome`, `codigo_barras`, `categoria`, `calorias`, `carboidratos`, `proteinas`, `gorduras`, `sodio`, `acucares`, `fibras`, `preco`, `criado_em`, `atualizado_em`) VALUES
(1, 'LEITE PO NINHO INTEGRAL', '7891000325858', 'en:Whole milk powder', 496.00, 37.60, 25.20, 26.80, 0.39, 37.60, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(2, 'Leite Integral Piracanjuba', '7898215151708', 'Leites UHT, Leites integrais', 58.00, 4.60, 3.10, 3.00, 0.06, 4.60, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(3, 'Kit Kat', '7891000248768', 'en:Chocolate confectioneries filled with wafer', 527.71, 57.00, 7.80, 30.00, 0.09, 47.00, 2.20, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(4, 'Leite UHT Integral', '7898080640611', 'Leites UHT, en:Whole pasteurised milks', 59.00, 4.80, 3.10, 3.00, 0.06, 4.80, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(5, 'Creme de Leite Piracanjuba', '7898215151784', 'Leites UHT, Cremes UHT, Leites integrais', 182.00, 4.30, 2.90, 17.00, 0.08, 4.30, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(6, 'leite condensado Piracanjuba', '7898215152002', 'Leites condensados', 305.00, 55.00, 8.00, 6.00, 0.13, 55.00, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(7, 'Leite Condensado', '7898080640413', 'Leites condensados', 305.00, 55.00, 7.50, 6.00, 0.13, 55.00, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(8, 'Pão de forma integral (36% Cereais integrais)', '7891962051345', 'Pães de forma integral', 269.00, 49.00, 8.70, 4.20, 0.40, 12.00, 4.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(9, 'Leite em pó integral instantâneo Ninho', '7891000393284', 'Leites, en:Milk powders, leite em pó', 496.00, 37.60, 25.20, 26.80, 0.40, 36.00, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(10, 'Creme de Leite UHT Italac', '7898080640222', 'fr:Crèmes légères, creme de leite', 173.33, 4.67, 3.33, 15.33, 0.07, 4.67, 0.00, NULL, '2026-09-11 13:15:07', '2026-09-11 13:15:07'),
(11, 'Mini Biscoitos de Arroz Integral Camil Natural', '7896006779674', 'en:Puffed wholegrain rice cakes', 388.00, 80.00, 8.00, 2.33, 0.21, 0.00, 2.67, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(12, 'RISO SCOTTI - Arroz Basmati Natural Scotti', '8001860260315', 'en:White rices, Arrozes basmati', 351.00, 73.30, 0.80, 1.30, 0.00, 0.10, 1.30, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(13, 'Biscoitos de Arroz Integral Chia e Linhaça', '7896006716471', 'en:Gluten-free biscuits, en:Puffed wholegrain rice cakes', 380.00, 76.67, 9.00, 4.67, 0.17, 12.00, 5.00, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(14, 'Biscoito de arroz', '7896006716464', 'Biscuits', 373.33, 80.00, 7.67, 2.00, NULL, 2.00, 5.00, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(15, 'Arroz Namorando', '7896079431158', 'Arrozes', 161.00, 30.00, 3.20, 2.80, NULL, NULL, NULL, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(16, 'Biscoito de Arroz', '7896283007460', 'Biscuits', 336.67, 80.00, 6.67, 10.00, NULL, NULL, 5.00, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(17, 'Cereal Infantil Integral Arroz Aveia Mucilon Pacote 180g', '7891000319543', 'Cereal infantil', 376.19, 80.95, 6.67, 0.00, NULL, NULL, NULL, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(18, 'Arroz Polido Tipo 1', '7896062699961', 'Arroces', 352.00, 76.00, 8.00, 1.40, 0.00, 0.00, 0.00, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(19, 'Arroz Integral', '7896006755517', 'en:Brown rices, Arrozes Parbolizados, Arrozes integrais', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 5.50, '2026-09-11 13:15:17', '2026-09-12 20:22:27'),
(20, 'Biscoito de arroz', '7896546160017', NULL, 360.00, 76.67, 7.33, 2.00, NULL, 1.67, 4.67, NULL, '2026-09-11 13:15:17', '2026-09-11 13:15:17'),
(21, 'Feijão Carioca Tipo 1 Pantera Premium Pacote 1kg', '7896070800014', 'Feijões comuns, grãos-de-cereias', 205.00, 28.33, 18.33, 0.00, 0.01, 0.00, 41.67, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(22, 'Feijão carioca kicaldo', '7896116900029', 'Alimentos à base de frutas e legumes, Feijões comuns', 71.00, 15.00, 4.80, 0.50, 0.00, 0.70, 7.00, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(23, 'Feijão Preto', '7898007290202', NULL, 243.33, 36.67, 21.67, 1.17, NULL, 1.00, 21.67, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(24, 'Feijão Preto', '7890300155929', 'Alimentos à base de vegetais, Feijões comuns, Alimentos enlatados, Leguminosas e seus produtos', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(25, 'Feijão preto', '7896200115360', 'Feijões comuns, Feijões', 198.33, 30.00, 15.50, 2.00, 0.00, 0.00, 35.00, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(26, 'Feijão Carioca Tipo 1 (cálcio 62mg, ferro 4mg)', '7896099100256', NULL, 261.67, 65.00, 18.72, 0.00, 0.00, NULL, 21.67, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(27, 'Feijão carioca comum tipo 1', '7896200115346', 'Pulsos, Grãos de cereais', 178.33, 25.00, 18.33, 0.00, 38.95, NULL, 40.00, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(28, 'Feijão Carioca', '7896062602008', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(29, 'Feijão Caldo Nobre - Feijão Tradicional', '7898276600108', 'Feijão', 261.67, 48.33, 18.87, 0.00, 0.00, 0.00, 21.67, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(30, 'Feijão Preto S. Máximo Tipo 1 1kg', '7896401100097', 'Feijões comuns', 266.67, 40.00, 20.00, 1.67, 0.00, 0.00, 20.00, NULL, '2026-09-11 13:41:36', '2026-09-11 13:41:36'),
(41, 'Café Torrado E Moído Tradicional Melitta Caixa 500g', '7891021006125', 'Bebidas quentes, en:Coffee beans, Café', 15.00, 0.00, 0.00, 0.00, 0.00, 0.00, 0.00, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(42, 'cappuccino clássi', '7896005800157', 'en:Cappuccino, Cafe-em-po, Café solúvel', 425.00, 70.00, 12.00, 10.50, 0.55, 55.00, 0.00, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(43, 'Tradicional', '7891021006071', 'Cafés instantâneos, Cafés do Brasil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(44, 'Avellana', '7701362014904', 'Cafés Arábica, Café de Colombia, en:Freeze-dried instant coffees', 237.00, 37.00, 20.00, 1.00, 0.03, 5.00, 0.00, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(45, 'Nescafé Original Extraforte', '7891000300503', 'Bebidas, Produtos sem glútem, Cafés instantâneos, Cafés do Brasil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(46, 'Pilao Traditional Coffee', '7896089012637', 'Café expresso sem açúcar, Café instantâneo descafeinado sem açúcar', 20.00, 3.20, 0.00, 0.00, 0.00, 0.00, 3.20, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(47, 'Café Em Cápsula Torrado E Moído Intenso Espresso Illy Caixa 57g 10 Unidades', '8003753158761', 'Bebidas, Cafés', 0.00, 0.00, 0.00, 0.00, NULL, NULL, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(48, 'Gourmet Cerrado Mineiro', '7896045101658', 'en:Arabica coffees, Cafés do Brasil', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(49, 'Nescafé Café Soluvel Matinal', '7891000315507', 'Cafés, Cafés instantâneos', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(50, 'CAFÉ INSTANTÁNEO', '0400050248214', 'Cafés', 220.00, 37.00, 20.00, 0.50, 0.03, 5.00, NULL, NULL, '2026-09-12 20:29:11', '2026-09-12 20:29:11'),
(123, 'Arroz branco cozido', 'TACO0123', 'Cereais', 128.00, 28.10, 2.50, 0.20, 0.01, 0.00, 1.60, 5.50, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(124, 'Arroz integral cozido', 'TACO0124', 'Cereais', 124.00, 25.80, 2.60, 1.00, 0.01, 0.00, 2.70, 7.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(125, 'Arroz parboilizado cozido', 'TACO0125', 'Cereais', 123.00, 26.50, 2.50, 0.30, 0.01, 0.00, 1.10, 6.20, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(126, 'Macarrão cozido', 'TACO0126', 'Cereais', 158.00, 31.70, 5.80, 0.90, 0.01, 0.00, 1.60, 4.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(127, 'Macarrão instantâneo', 'TACO0127', 'Cereais', 436.00, 58.70, 9.40, 17.20, 1.90, 0.50, 2.30, 3.50, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(128, 'Pão francês', 'TACO0128', 'Cereais', 300.00, 58.60, 8.00, 3.10, 1.20, 1.50, 2.30, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(129, 'Pão de forma integral', 'TACO0129', 'Cereais', 253.00, 49.90, 9.40, 3.70, 1.20, 4.50, 6.90, 8.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(130, 'Pão de queijo assado', 'TACO0130', 'Cereais', 363.00, 37.60, 5.10, 21.60, 1.00, 1.00, 1.00, 19.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(131, 'Biscoito cream cracker', 'TACO0131', 'Cereais', 432.00, 68.70, 10.10, 14.40, 2.00, 2.00, 2.50, 6.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(132, 'Biscoito recheado chocolate', 'TACO0132', 'Cereais', 472.00, 70.50, 6.40, 19.60, 1.00, 35.00, 2.00, 4.50, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(133, 'Biscoito de arroz integral', 'TACO0133', 'Cereais', 387.00, 80.00, 8.00, 2.30, 0.05, 0.00, 2.00, 5.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(134, 'Aveia em flocos crua', 'TACO0134', 'Cereais', 394.00, 66.60, 13.90, 8.50, 0.05, 0.00, 9.10, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(135, 'Farinha de trigo', 'TACO0135', 'Cereais', 360.00, 75.10, 9.80, 1.40, 0.01, 0.00, 2.30, 4.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(136, 'Farinha de mandioca', 'TACO0136', 'Cereais', 361.00, 87.90, 1.60, 0.30, 0.01, 0.00, 6.40, 6.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(137, 'Fubá de milho', 'TACO0137', 'Cereais', 351.00, 78.90, 7.20, 1.90, 0.01, 0.00, 5.50, 5.50, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(138, 'Cuscuz de milho cozido', 'TACO0138', 'Cereais', 113.00, 25.30, 2.00, 0.70, 0.01, 0.00, 1.20, 5.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(139, 'Tapioca (goma)', 'TACO0139', 'Cereais', 240.00, 60.00, 0.00, 0.00, 0.01, 0.00, 0.60, 9.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(140, 'Granola', 'TACO0140', 'Cereais', 445.00, 66.20, 11.20, 14.60, 0.10, 20.00, 8.50, 24.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(141, 'Cereal matinal milho', 'TACO0141', 'Cereais', 370.00, 83.10, 7.20, 1.00, 0.60, 8.00, 5.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(142, 'Quinoa em grãos', 'TACO0142', 'Cereais', 367.00, 64.20, 14.10, 6.10, 0.01, 0.00, 7.00, 29.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(143, 'Feijão carioca cozido', 'TACO0143', 'Leguminosas', 76.00, 13.60, 4.80, 0.50, 0.01, 0.00, 8.50, 8.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(144, 'Feijão preto cozido', 'TACO0144', 'Leguminosas', 77.00, 14.00, 4.50, 0.50, 0.01, 0.00, 8.40, 9.20, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(145, 'Feijão branco cozido', 'TACO0145', 'Leguminosas', 104.00, 15.00, 6.60, 0.80, 0.16, 0.20, 5.40, 11.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(146, 'Feijão fradinho cozido', 'TACO0146', 'Leguminosas', 78.00, 13.50, 4.90, 0.60, 0.01, 0.00, 4.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(147, 'Lentilha cozida', 'TACO0147', 'Leguminosas', 116.00, 20.00, 9.00, 0.40, 0.01, 0.40, 7.90, 8.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(148, 'Grão-de-bico cozido', 'TACO0148', 'Leguminosas', 164.00, 27.40, 8.90, 2.60, 0.01, 0.50, 7.60, 9.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(149, 'Soja cozida', 'TACO0149', 'Leguminosas', 172.00, 9.90, 16.60, 9.00, 0.01, 0.50, 6.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(150, 'Ervilha em vagem cozida', 'TACO0150', 'Leguminosas', 63.00, 11.20, 4.30, 0.30, 0.01, 3.00, 5.10, 9.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(151, 'Amendoim cru', 'TACO0151', 'Leguminosas', 544.00, 20.30, 27.20, 43.90, 0.01, 4.00, 8.00, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(152, 'Tofu firme', 'TACO0152', 'Leguminosas', 76.00, 1.90, 8.10, 4.80, 0.01, 0.60, 0.30, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(153, 'Picanha bovina grelhada', 'TACO0153', 'Carnes bovinas', 289.00, 0.00, 26.40, 19.80, 0.05, 0.00, 0.00, 79.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(154, 'Alcatra bovina grelhada', 'TACO0154', 'Carnes bovinas', 241.00, 0.00, 31.90, 11.60, 0.06, 0.00, 0.00, 59.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(155, 'Contrafilé bovino grelhado', 'TACO0155', 'Carnes bovinas', 278.00, 0.00, 32.00, 16.00, 0.06, 0.00, 0.00, 54.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(156, 'Coxão mole bovino cozido', 'TACO0156', 'Carnes bovinas', 219.00, 0.00, 31.90, 9.20, 0.07, 0.00, 0.00, 44.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(157, 'Coxão duro bovino cozido', 'TACO0157', 'Carnes bovinas', 217.00, 0.00, 31.90, 8.90, 0.07, 0.00, 0.00, 39.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(158, 'Patinho bovino moído cozido', 'TACO0158', 'Carnes bovinas', 212.00, 0.00, 35.90, 7.30, 0.08, 0.00, 0.00, 39.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(159, 'Acém bovino cozido', 'TACO0159', 'Carnes bovinas', 215.00, 0.00, 26.70, 11.20, 0.08, 0.00, 0.00, 34.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(160, 'Músculo bovino cozido', 'TACO0160', 'Carnes bovinas', 194.00, 0.00, 31.20, 6.70, 0.08, 0.00, 0.00, 32.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(161, 'Carne seca bovina', 'TACO0161', 'Carnes bovinas', 313.00, 0.00, 33.00, 19.70, 5.20, 0.00, 0.00, 69.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(162, 'Costela bovina assada', 'TACO0162', 'Carnes bovinas', 373.00, 0.00, 28.80, 27.70, 0.06, 0.00, 0.00, 49.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(163, 'Fígado bovino grelhado', 'TACO0163', 'Carnes bovinas', 225.00, 0.00, 29.90, 9.00, 0.10, 0.00, 0.00, 24.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(164, 'Coração bovino cozido', 'TACO0164', 'Carnes bovinas', 165.00, 0.00, 29.20, 5.10, 0.10, 0.00, 0.00, 32.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(165, 'Peito de frango grelhado', 'TACO0165', 'Aves', 159.00, 0.00, 32.00, 2.50, 0.06, 0.00, 0.00, 24.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(166, 'Coxa de frango assada', 'TACO0166', 'Aves', 215.00, 0.00, 27.10, 11.00, 0.10, 0.00, 0.00, 19.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(167, 'Sobrecoxa de frango assada', 'TACO0167', 'Aves', 232.00, 0.00, 26.40, 13.30, 0.10, 0.00, 0.00, 18.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(168, 'Frango inteiro assado', 'TACO0168', 'Aves', 231.00, 0.00, 27.10, 13.10, 0.08, 0.00, 0.00, 16.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(169, 'Asa de frango assada', 'TACO0169', 'Aves', 232.00, 0.00, 27.30, 12.80, 0.10, 0.00, 0.00, 22.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(170, 'Peito de peru defumado', 'TACO0170', 'Aves', 106.00, 1.80, 17.30, 3.30, 1.20, 0.50, 0.00, 42.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(171, 'Chester assado', 'TACO0171', 'Aves', 219.00, 0.00, 28.00, 11.00, 0.08, 0.00, 0.00, 34.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(172, 'Lombo suíno assado', 'TACO0172', 'Carnes suínas', 210.00, 0.00, 35.70, 6.40, 0.08, 0.00, 0.00, 32.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(173, 'Bisteca suína grelhada', 'TACO0173', 'Carnes suínas', 242.00, 0.00, 28.00, 13.50, 0.08, 0.00, 0.00, 28.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(174, 'Pernil suíno assado', 'TACO0174', 'Carnes suínas', 262.00, 0.00, 29.10, 15.50, 0.08, 0.00, 0.00, 26.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(175, 'Bacon frito', 'TACO0175', 'Carnes suínas', 541.00, 0.00, 37.00, 43.00, 1.90, 0.00, 0.00, 39.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(176, 'Linguiça suína grelhada', 'TACO0176', 'Carnes suínas', 320.00, 0.00, 16.00, 28.00, 1.20, 0.00, 0.00, 22.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(177, 'Lombo suíno cru', 'TACO0177', 'Carnes suínas', 176.00, 0.00, 22.60, 8.80, 0.06, 0.00, 0.00, 27.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(178, 'Tilápia grelhada', 'TACO0178', 'Peixes', 128.00, 0.00, 26.20, 2.70, 0.06, 0.00, 0.00, 34.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(179, 'Salmão grelhado', 'TACO0179', 'Peixes', 229.00, 0.00, 25.90, 13.30, 0.06, 0.00, 0.00, 89.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(180, 'Sardinha em conserva', 'TACO0180', 'Peixes', 189.00, 0.00, 22.30, 10.20, 0.70, 0.00, 0.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(181, 'Atum em conserva (água)', 'TACO0181', 'Peixes', 116.00, 0.00, 26.20, 0.80, 0.40, 0.00, 0.00, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(182, 'Atum em conserva (óleo)', 'TACO0182', 'Peixes', 166.00, 0.00, 26.20, 6.00, 0.40, 0.00, 0.00, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(183, 'Merluza cozida', 'TACO0183', 'Peixes', 122.00, 0.00, 26.60, 0.90, 0.08, 0.00, 0.00, 39.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(184, 'Tambaqui grelhado', 'TACO0184', 'Peixes', 230.00, 0.00, 24.00, 14.20, 0.06, 0.00, 0.00, 49.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(185, 'Pintado grelhado', 'TACO0185', 'Peixes', 152.00, 0.00, 28.00, 4.00, 0.06, 0.00, 0.00, 59.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(186, 'Bacalhau salgado', 'TACO0186', 'Peixes', 136.00, 0.00, 29.00, 1.30, 14.00, 0.00, 0.00, 89.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(187, 'Camarão cozido', 'TACO0187', 'Frutos do mar', 90.00, 0.00, 19.00, 1.00, 0.20, 0.00, 0.00, 59.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(188, 'Lula cozida', 'TACO0188', 'Frutos do mar', 92.00, 2.90, 15.60, 1.60, 0.04, 0.00, 0.00, 44.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(189, 'Ovo de galinha cozido', 'TACO0189', 'Ovos', 146.00, 0.60, 13.30, 9.50, 0.14, 0.60, 0.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(190, 'Ovo de galinha frito', 'TACO0190', 'Ovos', 240.00, 0.60, 15.60, 18.60, 0.20, 0.60, 0.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(191, 'Ovo mexido', 'TACO0191', 'Ovos', 180.00, 1.00, 13.00, 13.50, 0.16, 0.60, 0.00, 12.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(192, 'Clara de ovo cozida', 'TACO0192', 'Ovos', 59.00, 0.30, 13.40, 0.10, 0.16, 0.20, 0.00, 14.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(193, 'Gema de ovo cozida', 'TACO0193', 'Ovos', 353.00, 0.60, 16.00, 30.80, 0.10, 0.60, 0.00, 18.90, '2026-09-13 08:41:59', '2026-09-13 08:42:39'),
(194, 'Leite integral', 'TACO0194', 'Leites', 61.00, 4.70, 3.20, 3.20, 0.05, 4.70, 0.00, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(195, 'Leite desnatado', 'TACO0195', 'Leites', 34.00, 5.00, 3.40, 0.20, 0.05, 5.00, 0.00, 5.20, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(196, 'Leite semidesnatado', 'TACO0196', 'Leites', 51.00, 4.80, 3.20, 2.00, 0.05, 4.80, 0.00, 5.00, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(197, 'Iogurte natural integral', 'TACO0197', 'Leites', 51.00, 1.90, 4.10, 3.00, 0.05, 1.90, 0.00, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(198, 'Iogurte natural desnatado', 'TACO0198', 'Leites', 41.00, 3.30, 4.60, 0.70, 0.06, 3.30, 0.00, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(199, 'Iogurte morango', 'TACO0199', 'Leites', 84.00, 15.30, 2.80, 1.50, 0.05, 12.00, 0.00, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(200, 'Requeijão cremoso', 'TACO0200', 'Leites', 257.00, 2.40, 9.60, 23.40, 0.50, 2.40, 0.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(201, 'Queijo mussarela', 'TACO0201', 'Queijos', 330.00, 3.00, 22.60, 25.20, 0.60, 3.00, 0.00, 42.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(202, 'Queijo prato', 'TACO0202', 'Queijos', 360.00, 1.40, 22.70, 29.10, 0.60, 1.40, 0.00, 44.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(203, 'Queijo minas frescal', 'TACO0203', 'Queijos', 264.00, 3.20, 17.40, 20.20, 0.10, 3.20, 0.00, 32.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(204, 'Queijo parmesão', 'TACO0204', 'Queijos', 453.00, 1.60, 35.50, 33.60, 1.60, 1.60, 0.00, 59.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(205, 'Queijo ricota', 'TACO0205', 'Queijos', 140.00, 3.80, 12.60, 8.10, 0.30, 3.80, 0.00, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(206, 'Manteiga sem sal', 'TACO0206', 'Leites', 726.00, 0.10, 0.40, 82.40, 0.01, 0.10, 0.00, 39.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(207, 'Margarina com sal', 'TACO0207', 'Leites', 596.00, 0.00, 0.20, 66.00, 0.60, 0.00, 0.00, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(208, 'Creme de leite', 'TACO0208', 'Leites', 221.00, 4.50, 1.50, 21.40, 0.05, 4.50, 0.00, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(209, 'Leite condensado', 'TACO0209', 'Leites', 313.00, 57.20, 7.70, 6.70, 0.15, 57.00, 0.00, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(210, 'Alface crespa crua', 'TACO0210', 'Hortaliças', 11.00, 1.70, 1.30, 0.20, 0.01, 0.50, 1.80, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(211, 'Rúcula crua', 'TACO0211', 'Hortaliças', 13.00, 2.20, 1.80, 0.10, 0.01, 0.50, 1.70, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(212, 'Couve manteiga crua', 'TACO0212', 'Hortaliças', 27.00, 4.30, 2.90, 0.50, 0.01, 0.50, 3.10, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(213, 'Espinafre cru', 'TACO0213', 'Hortaliças', 16.00, 2.60, 2.10, 0.20, 0.01, 0.50, 2.10, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(214, 'Brócolis cozido', 'TACO0214', 'Hortaliças', 25.00, 4.40, 2.10, 0.50, 0.01, 1.00, 3.40, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(215, 'Couve-flor cozida', 'TACO0215', 'Hortaliças', 19.00, 3.90, 1.20, 0.30, 0.01, 1.00, 2.10, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(216, 'Cenoura crua', 'TACO0216', 'Hortaliças', 34.00, 7.70, 1.30, 0.20, 0.01, 3.30, 3.20, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(217, 'Tomate cru', 'TACO0217', 'Hortaliças', 15.00, 3.10, 1.10, 0.20, 0.01, 2.50, 1.20, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(218, 'Pepino cru', 'TACO0218', 'Hortaliças', 10.00, 2.00, 0.90, 0.10, 0.01, 1.40, 1.10, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(219, 'Cebola crua', 'TACO0219', 'Hortaliças', 39.00, 8.90, 1.70, 0.10, 0.01, 5.00, 2.20, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(220, 'Alho cru', 'TACO0220', 'Hortaliças', 113.00, 23.90, 7.00, 0.20, 0.01, 1.00, 4.30, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(221, 'Batata inglesa cozida', 'TACO0221', 'Hortaliças', 52.00, 11.90, 1.20, 0.00, 0.01, 0.50, 1.30, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(222, 'Batata-doce cozida', 'TACO0222', 'Hortaliças', 77.00, 18.40, 0.60, 0.10, 0.01, 5.00, 2.20, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(223, 'Mandioca cozida', 'TACO0223', 'Hortaliças', 125.00, 30.10, 0.60, 0.30, 0.01, 1.50, 1.60, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(224, 'Abóbora cozida', 'TACO0224', 'Hortaliças', 48.00, 12.20, 1.00, 0.10, 0.01, 3.00, 1.70, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(225, 'Beterraba crua', 'TACO0225', 'Hortaliças', 49.00, 11.10, 1.90, 0.10, 0.01, 7.00, 3.40, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(226, 'Chuchu cozido', 'TACO0226', 'Hortaliças', 19.00, 4.80, 0.40, 0.00, 0.01, 2.00, 1.00, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(227, 'Quiabo cru', 'TACO0227', 'Hortaliças', 30.00, 6.40, 1.90, 0.20, 0.01, 1.00, 4.60, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(228, 'Berinjela crua', 'TACO0228', 'Hortaliças', 20.00, 5.30, 0.90, 0.10, 0.01, 2.50, 2.90, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(229, 'Pimentão verde cru', 'TACO0229', 'Hortaliças', 21.00, 4.90, 1.10, 0.20, 0.01, 2.50, 2.60, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(230, 'Banana prata crua', 'TACO0230', 'Frutas', 98.00, 26.00, 1.30, 0.10, 0.01, 18.00, 2.00, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(231, 'Banana nanica crua', 'TACO0231', 'Frutas', 92.00, 23.80, 1.40, 0.10, 0.01, 16.00, 1.90, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(232, 'Maçã com casca', 'TACO0232', 'Frutas', 56.00, 15.20, 0.30, 0.20, 0.01, 12.00, 2.00, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(233, 'Laranja pera', 'TACO0233', 'Frutas', 37.00, 8.90, 1.00, 0.10, 0.01, 7.00, 0.80, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(234, 'Mamão papaia', 'TACO0234', 'Frutas', 40.00, 10.40, 0.50, 0.10, 0.01, 8.00, 1.80, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(235, 'Manga palmer', 'TACO0235', 'Frutas', 72.00, 19.20, 0.40, 0.20, 0.01, 15.00, 1.60, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(236, 'Abacaxi cru', 'TACO0236', 'Frutas', 48.00, 12.30, 0.90, 0.10, 0.01, 10.00, 1.00, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(237, 'Melancia crua', 'TACO0237', 'Frutas', 33.00, 8.10, 0.90, 0.00, 0.01, 6.00, 0.10, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(238, 'Melão cru', 'TACO0238', 'Frutas', 29.00, 7.50, 0.70, 0.00, 0.01, 6.50, 0.30, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(239, 'Uva itália', 'TACO0239', 'Frutas', 53.00, 13.60, 0.70, 0.20, 0.01, 12.00, 0.90, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(240, 'Morango cru', 'TACO0240', 'Frutas', 30.00, 6.80, 0.90, 0.30, 0.01, 5.00, 1.70, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(241, 'Kiwi', 'TACO0241', 'Frutas', 51.00, 11.50, 1.30, 0.60, 0.01, 9.00, 2.70, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(242, 'Pera williams', 'TACO0242', 'Frutas', 53.00, 14.00, 0.60, 0.10, 0.01, 11.00, 3.00, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(243, 'Goiaba vermelha', 'TACO0243', 'Frutas', 54.00, 13.00, 1.10, 0.40, 0.01, 8.00, 6.20, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(244, 'Maracujá cru', 'TACO0244', 'Frutas', 68.00, 12.30, 2.00, 2.10, 0.01, 8.00, 1.10, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(245, 'Limão taiti', 'TACO0245', 'Frutas', 32.00, 11.10, 0.90, 0.10, 0.01, 2.50, 0.90, 6.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(246, 'Acerola crua', 'TACO0246', 'Frutas', 33.00, 8.00, 0.90, 0.20, 0.01, 4.00, 1.50, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(247, 'Caju cru', 'TACO0247', 'Frutas', 43.00, 10.30, 1.00, 0.30, 0.01, 8.00, 1.70, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(248, 'Pêssego cru', 'TACO0248', 'Frutas', 39.00, 9.30, 0.80, 0.10, 0.01, 8.00, 1.40, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(249, 'Ameixa crua', 'TACO0249', 'Frutas', 46.00, 11.40, 0.80, 0.00, 0.01, 9.00, 1.90, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(250, 'Azeite de oliva extravirgem', 'TACO0250', 'Gorduras', 884.00, 0.00, 0.00, 100.00, 0.01, 0.00, 0.00, 39.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(251, 'Óleo de soja', 'TACO0251', 'Gorduras', 884.00, 0.00, 0.00, 100.00, 0.01, 0.00, 0.00, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(252, 'Óleo de girassol', 'TACO0252', 'Gorduras', 884.00, 0.00, 0.00, 100.00, 0.01, 0.00, 0.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(253, 'Óleo de canola', 'TACO0253', 'Gorduras', 884.00, 0.00, 0.00, 100.00, 0.01, 0.00, 0.00, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(254, 'Óleo de coco', 'TACO0254', 'Gorduras', 862.00, 0.00, 0.00, 100.00, 0.01, 0.00, 0.00, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(255, 'Banha suína', 'TACO0255', 'Gorduras', 898.00, 0.00, 0.00, 99.80, 0.01, 0.00, 0.00, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(256, 'Açúcar cristal', 'TACO0256', 'Açúcares', 387.00, 99.90, 0.00, 0.00, 0.01, 99.90, 0.00, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(257, 'Açúcar mascavo', 'TACO0257', 'Açúcares', 369.00, 94.50, 0.80, 0.10, 0.05, 90.00, 0.00, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(258, 'Mel de abelha', 'TACO0258', 'Açúcares', 309.00, 84.00, 0.00, 0.00, 0.01, 82.00, 0.00, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(259, 'Chocolate ao leite', 'TACO0259', 'Açúcares', 540.00, 59.60, 7.20, 30.30, 0.10, 52.00, 2.50, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(260, 'Chocolate meio amargo', 'TACO0260', 'Açúcares', 535.00, 62.00, 5.00, 30.00, 0.02, 48.00, 5.00, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(261, 'Doce de leite', 'TACO0261', 'Açúcares', 306.00, 59.50, 5.50, 6.00, 0.15, 55.00, 0.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(262, 'Goiabada', 'TACO0262', 'Açúcares', 269.00, 70.30, 0.40, 0.10, 0.05, 65.00, 1.20, 14.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(263, 'Geleia de morango', 'TACO0263', 'Açúcares', 260.00, 65.00, 0.40, 0.10, 0.05, 60.00, 1.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(264, 'Café coado', 'TACO0264', 'Bebidas', 9.00, 1.50, 0.70, 0.10, 0.01, 0.00, 0.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(265, 'Café expresso', 'TACO0265', 'Bebidas', 3.00, 0.60, 0.10, 0.10, 0.01, 0.00, 0.00, 15.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(266, 'Chá mate', 'TACO0266', 'Bebidas', 3.00, 0.60, 0.00, 0.00, 0.01, 0.00, 0.00, 8.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(267, 'Suco de laranja natural', 'TACO0267', 'Bebidas', 37.00, 8.70, 0.60, 0.10, 0.01, 7.00, 0.20, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(268, 'Suco de maracujá natural', 'TACO0268', 'Bebidas', 42.00, 9.60, 0.70, 0.20, 0.01, 8.00, 0.30, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(269, 'Refrigerante cola', 'TACO0269', 'Bebidas', 34.00, 8.70, 0.00, 0.00, 0.05, 8.70, 0.00, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(270, 'Refrigerante guaraná', 'TACO0270', 'Bebidas', 39.00, 10.00, 0.00, 0.00, 0.04, 10.00, 0.00, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(271, 'Água de coco', 'TACO0271', 'Bebidas', 22.00, 5.30, 0.00, 0.00, 0.02, 4.50, 0.00, 5.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(272, 'Cerveja pilsen', 'TACO0272', 'Bebidas', 41.00, 3.30, 0.60, 0.00, 0.01, 0.00, 0.00, 4.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(273, 'Vinho tinto', 'TACO0273', 'Bebidas', 78.00, 2.50, 0.20, 0.00, 0.01, 0.50, 0.00, 29.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(274, 'Presunto cozido', 'TACO0274', 'Embutidos', 94.00, 1.50, 17.00, 2.00, 2.20, 0.60, 0.00, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(275, 'Mortadela', 'TACO0275', 'Embutidos', 268.00, 5.00, 12.00, 22.00, 1.50, 0.50, 0.00, 15.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(276, 'Salame italiano', 'TACO0276', 'Embutidos', 398.00, 2.50, 25.00, 32.00, 2.30, 0.50, 0.00, 44.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(277, 'Salsicha', 'TACO0277', 'Embutidos', 257.00, 3.00, 12.00, 22.00, 1.30, 0.50, 0.00, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(278, 'Hambúrguer bovino congelado', 'TACO0278', 'Embutidos', 211.00, 3.00, 16.00, 14.50, 0.80, 0.50, 0.00, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(279, 'Nuggets de frango', 'TACO0279', 'Embutidos', 252.00, 20.00, 15.00, 12.00, 1.10, 1.50, 1.00, 18.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(280, 'Peito de peru em fatias', 'TACO0280', 'Embutidos', 89.00, 1.00, 18.60, 1.20, 1.80, 0.50, 0.00, 29.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(281, 'Feijoada', 'TACO0281', 'Pratos prontos', 117.00, 7.50, 8.70, 5.30, 0.60, 0.50, 3.20, 29.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(282, 'Estrogonofe de carne', 'TACO0282', 'Pratos prontos', 156.00, 5.00, 12.00, 9.30, 0.50, 1.50, 0.60, 24.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(283, 'Lasanha bolonhesa', 'TACO0283', 'Pratos prontos', 157.00, 17.50, 9.70, 5.40, 0.60, 2.00, 0.80, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(284, 'Pizza mussarela', 'TACO0284', 'Pratos prontos', 256.00, 30.00, 12.00, 9.50, 0.60, 2.50, 1.20, 34.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(285, 'Coxinha de frango', 'TACO0285', 'Pratos prontos', 289.00, 32.00, 9.00, 14.00, 0.60, 1.00, 1.50, 7.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(286, 'Pão de queijo assado', 'TACO0286', 'Pratos prontos', 363.00, 37.60, 5.10, 21.60, 1.00, 1.00, 1.00, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(287, 'Cachorro-quente', 'TACO0287', 'Pratos prontos', 278.00, 28.00, 9.00, 14.00, 1.20, 3.50, 1.80, 12.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(288, 'Tapioca simples', 'TACO0288', 'Pratos prontos', 240.00, 60.00, 0.00, 0.00, 0.01, 0.00, 0.60, 9.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39'),
(289, 'Baião de dois', 'TACO0289', 'Pratos prontos', 145.00, 22.00, 6.20, 4.20, 0.40, 0.50, 2.00, 19.90, '2026-09-13 08:42:00', '2026-09-13 08:42:39');

-- --------------------------------------------------------

--
-- Estrutura para tabela `historico_pesquisas`
--

CREATE TABLE `historico_pesquisas` (
  `id` int(10) UNSIGNED NOT NULL,
  `usuario_id` int(10) UNSIGNED NOT NULL,
  `alimento_id` int(10) UNSIGNED NOT NULL,
  `data_pesquisa` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `ranking_global`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `ranking_global` (
`alimento_id` int(10) unsigned
,`nome` varchar(500)
,`categoria` varchar(255)
,`total_pesquisas` bigint(21)
,`media_calorias` decimal(8,1)
,`media_proteinas` decimal(8,1)
,`pontuacao_saudavel` decimal(14,2)
);

-- --------------------------------------------------------

--
-- Estrutura stand-in para view `ranking_pessoal`
-- (Veja abaixo para a visão atual)
--
CREATE TABLE `ranking_pessoal` (
`usuario_id` int(10) unsigned
,`alimento_id` int(10) unsigned
,`nome` varchar(500)
,`categoria` varchar(255)
,`total_pesquisas` bigint(21)
,`media_calorias` decimal(8,1)
,`media_proteinas` decimal(8,1)
,`pontuacao_saudavel` decimal(14,2)
);

-- --------------------------------------------------------

--
-- Estrutura para tabela `usuarios`
--

CREATE TABLE `usuarios` (
  `id` int(10) UNSIGNED NOT NULL,
  `email` varchar(150) NOT NULL,
  `senha_hash` varchar(255) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `data_cadastro` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Despejando dados para a tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `email`, `senha_hash`, `nome`, `data_cadastro`) VALUES
(1, 'matias.2023319620@aluno.iffar.edu.br', '$2y$10$rU/MD.K0wJrptZKypj61TuA6NjGjidoPlIwzFpsYyoAtmaIiWUAdu', 'Matias Neto', '2026-09-11 13:13:00');

-- --------------------------------------------------------

--
-- Estrutura para view `ranking_global`
--
DROP TABLE IF EXISTS `ranking_global`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY INVOKER VIEW `ranking_global`  AS SELECT `a`.`id` AS `alimento_id`, `a`.`nome` AS `nome`, `a`.`categoria` AS `categoria`, count(`h`.`id`) AS `total_pesquisas`, round(avg(`a`.`calorias`),1) AS `media_calorias`, round(avg(`a`.`proteinas`),1) AS `media_proteinas`, round(greatest(0,avg(coalesce(`a`.`proteinas`,0)) * 2 - avg(coalesce(`a`.`calorias`,0)) / 10 - avg(coalesce(`a`.`gorduras`,0)) * 1.5 - avg(coalesce(`a`.`acucares`,0)) * 0.5 + avg(coalesce(`a`.`fibras`,0)) * 1.5),2) AS `pontuacao_saudavel` FROM (`historico_pesquisas` `h` join `alimentos` `a` on(`a`.`id` = `h`.`alimento_id`)) GROUP BY `a`.`id`, `a`.`nome`, `a`.`categoria` ;

-- --------------------------------------------------------

--
-- Estrutura para view `ranking_pessoal`
--
DROP TABLE IF EXISTS `ranking_pessoal`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`localhost` SQL SECURITY INVOKER VIEW `ranking_pessoal`  AS SELECT `u`.`id` AS `usuario_id`, `a`.`id` AS `alimento_id`, `a`.`nome` AS `nome`, `a`.`categoria` AS `categoria`, count(`h`.`id`) AS `total_pesquisas`, round(avg(`a`.`calorias`),1) AS `media_calorias`, round(avg(`a`.`proteinas`),1) AS `media_proteinas`, round(greatest(0,avg(coalesce(`a`.`proteinas`,0)) * 2 - avg(coalesce(`a`.`calorias`,0)) / 10 - avg(coalesce(`a`.`gorduras`,0)) * 1.5 - avg(coalesce(`a`.`acucares`,0)) * 0.5 + avg(coalesce(`a`.`fibras`,0)) * 1.5),2) AS `pontuacao_saudavel` FROM ((`historico_pesquisas` `h` join `alimentos` `a` on(`a`.`id` = `h`.`alimento_id`)) join `usuarios` `u` on(`u`.`id` = `h`.`usuario_id`)) GROUP BY `u`.`id`, `a`.`id`, `a`.`nome`, `a`.`categoria` ;

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `alimentos`
--
ALTER TABLE `alimentos`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_codigo_barras` (`codigo_barras`);
ALTER TABLE `alimentos` ADD FULLTEXT KEY `ft_nome` (`nome`);

--
-- Índices de tabela `historico_pesquisas`
--
ALTER TABLE `historico_pesquisas`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_usuario_data` (`usuario_id`,`data_pesquisa`),
  ADD KEY `idx_alimento` (`alimento_id`);

--
-- Índices de tabela `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `uq_email` (`email`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `alimentos`
--
ALTER TABLE `alimentos`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de tabela `historico_pesquisas`
--
ALTER TABLE `historico_pesquisas`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=503;

--
-- AUTO_INCREMENT de tabela `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Restrições para tabelas despejadas
--

--
-- Restrições para tabelas `historico_pesquisas`
--
ALTER TABLE `historico_pesquisas`
  ADD CONSTRAINT `fk_hist_alimento` FOREIGN KEY (`alimento_id`) REFERENCES `alimentos` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_hist_usuario` FOREIGN KEY (`usuario_id`) REFERENCES `usuarios` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
